

function setup() {

  createCanvas(400, 400);
} 


function draw() { 
  background(220);

  fill('brown');
 
  rect(195,200,20,100);
  fill('green');

  ellipse(205,175,70,70);
  
 
  fill('brown');
  
  rect(95,200,20,100);
  fill('green');
 
  ellipse(105,175,70,70);





var x = [12, 20]; 

print(x.length); 

var y = ["cat", 10, false, 50]; 

print(y.length); 

var z = []; 

print(z.length); 

z[0] = 20;  

print(z.length); 

z[1] = 4; 

print(z.length); 


}