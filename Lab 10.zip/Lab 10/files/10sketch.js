let vid;

function setup() {

  noCanvas();

  vid = createVideo(
    ['assets/astro.mp4', 'assets/astro.ogv', 'assets/astro.webm'],
    vidLoad
  );

  vid.size(320, 240);
}

// This function is called when the video loads
function vidLoad() {
  vid.loop();
  vid.showControls();
  vid.volume(0);
  vid.play();
}

