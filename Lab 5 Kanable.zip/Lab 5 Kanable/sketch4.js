
function setup() {
  createCanvas(400, 400);
}
function draw() {
  background(400);

if (keyIsPressed) {
  if (key == 'h') {}
  line (130, 160, 190, 160);
}
else if (key =='n') {
  line (130,120,190,200);
}
line(130,120,120,200);
line(190,120,190,200);
}